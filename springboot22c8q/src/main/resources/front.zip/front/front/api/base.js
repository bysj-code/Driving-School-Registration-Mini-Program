﻿const base = {
    url : "http://localhost:8080/springboot22c8q/"
}
export default base
